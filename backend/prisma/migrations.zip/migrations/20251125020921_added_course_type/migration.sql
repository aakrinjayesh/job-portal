-- AlterTable
ALTER TABLE "Course" ADD COLUMN     "courseType" TEXT;
