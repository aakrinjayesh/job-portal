-- AlterTable
ALTER TABLE "UserProfile" ADD COLUMN     "email" TEXT,
ADD COLUMN     "name" TEXT,
ADD COLUMN     "phoneNumber" TEXT,
ADD COLUMN     "portfolioLink" TEXT;
