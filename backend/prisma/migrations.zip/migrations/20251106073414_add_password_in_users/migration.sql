-- AlterTable
ALTER TABLE "Users" ADD COLUMN     "password" TEXT;
