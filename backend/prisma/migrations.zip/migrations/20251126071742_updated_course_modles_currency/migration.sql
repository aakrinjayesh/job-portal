-- AlterTable
ALTER TABLE "Course" ADD COLUMN     "currency" TEXT;
