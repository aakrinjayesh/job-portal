-- AlterTable
ALTER TABLE "Job" ADD COLUMN     "clouds" TEXT[];
