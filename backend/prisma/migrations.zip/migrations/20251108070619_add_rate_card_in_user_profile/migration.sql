-- AlterTable
ALTER TABLE "UserProfile" ADD COLUMN     "rateCardPerHour" JSONB;
